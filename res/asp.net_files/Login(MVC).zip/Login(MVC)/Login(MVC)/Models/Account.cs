﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Login_MVC_.Models
{
    public class Account
    {
       public  string userName { get; set; }
        public string Password { get; set; }

    }
}